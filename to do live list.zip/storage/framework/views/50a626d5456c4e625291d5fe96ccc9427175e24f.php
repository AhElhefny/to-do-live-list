<div class="row mb-2">
    <div class="col-sm-6">
        <h1><?php echo e($links['title']); ?></h1>
    </div>
    <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
            <?php if($links['linksData']): ?>
                <?php $__currentLoopData = $links['linksData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(route($value)); ?>"><?php echo e($key); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ol>
    </div>
</div>
<?php /**PATH D:\Dev-Ahm\to do live list\resources\views/layouts/breadcrumb.blade.php ENDPATH**/ ?>