<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php echo $__env->make('layouts.breadcrumb',['links' => ['title' => 'Home','linksData' => [
        'Home'=>'dashboard',
    ]]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-4 grid-margin">
            <div class="card">
                <div class="card-body">
                    <h5><i class="fa fa-user text-primary ml-auto mr-2"></i>Users</h5>
                    <div class="row">
                        <div class="col-8 col-sm-12 col-xl-8 my-auto">
                            <div class="d-flex d-sm-block d-md-flex align-items-center">
                                <h2 class="mb-0"><?php echo e(\App\Models\User::count()); ?></h2>
                            </div>
                            <?php $__currentLoopData = $userRolesCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$userRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h6 class="text-muted font-weight-normal d-flex justify-content-between"><span><?php echo e(preg_replace('/[^A-Za-z0-9\-]/', ' ', strtoupper($key))); ?></span><span class="badge badge-primary"><?php echo e($userRole); ?></span></h6>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Dev-Ahm\to do live list\resources\views/admin/home.blade.php ENDPATH**/ ?>